#include "Graph.hpp"
#include<vector>
#include<iostream>
using namespace std;

int main()
{
	Graph graph;
	graph.addVertex("Aurora");
	graph.addVertex("Bloomington");
	graph.addVertex("Cheyenne");
	graph.addVertex("Denver");
	graph.addVertex("Fruita");
	// graph.addVertex("Cheyenne");
	// graph.addVertex("London");
	// graph.addVertex("Paris");


	graph.addEdge("Aurora", "Bloomington", 5);
	graph.addEdge("Aurora", "Cheyenne", 10);
	graph.addEdge("Aurora", "Fruita", 30);

	graph.addEdge("Bloomington", "Denver", 40);
	graph.addEdge("Bloomington", "Fruita", 15);
		
	graph.addEdge("Cheyenne", "Denver", 10);
	
	// graph.addEdge("Denver", "Fruita");

	// graph.addEdge("Longmont", "Moab");
	
	// graph.addEdge("London", "Paris");

	graph.depthFirstTraversal("Aurora");

}