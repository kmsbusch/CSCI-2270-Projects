g++ -std=c++11 .\Album.cpp .\Album.h .\Artist.cpp .\Artist.h .\Hash.cpp .\Hash.h .\main.cpp .\Song.cpp .\Song.h

.\a.exe

Or 

.\plsworkffs.exe